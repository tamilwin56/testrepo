Process payments using beneficiary details from the PAYMENT.ORDER application and verify that the STATUS.CODE updates correctly
SCRPT10005-1�SCRPT10005-2�SCRPT10005-3�SCRPT10005-4
���








1
88682_AUTHORISER__OFS_BROWSERTC
2511191406
85421_INPUTTER_OFS_BROWSERTC
GB0010001
1
